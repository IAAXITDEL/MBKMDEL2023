import 'package:get/get.dart';

class ReturndevicepilotController extends GetxController {
  //TODO: Implement ReturndevicepilotController

  final count = 0.obs;



  void increment() => count.value++;
}
