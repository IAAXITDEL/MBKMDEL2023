import 'package:get/get.dart';

class HomeAdminccController extends GetxController {
  //TODO: Implement HomeAdminccController

  final count = 0.obs;



  void increment() => count.value++;
}
