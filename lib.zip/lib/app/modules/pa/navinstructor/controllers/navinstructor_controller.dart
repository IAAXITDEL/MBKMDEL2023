import 'package:get/get.dart';

class NavinstructorController extends GetxController {
  //TODO: Implement NavinstructorController

  final count = 0.obs;



  void increment() => count.value++;
}
