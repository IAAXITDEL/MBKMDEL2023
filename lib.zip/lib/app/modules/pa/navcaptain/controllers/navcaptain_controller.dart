import 'package:get/get.dart';

class NavcaptainController extends GetxController {
  //TODO: Implement NavcaptainController

  final count = 0.obs;



  void increment() => count.value++;
}
